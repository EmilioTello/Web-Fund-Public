function logout(element){
    element.innerText = "Logout";
}
function hide(element){
    element.remove();
}