var count = 3;
var newNumber = document.querySelector(".number");

function increase(){
    count++;
    newNumber.innerText = count;
}